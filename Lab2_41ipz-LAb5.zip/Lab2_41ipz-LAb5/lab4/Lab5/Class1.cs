﻿using System;

namespace Lab5
{
    public class Class1
    {

    }
}
